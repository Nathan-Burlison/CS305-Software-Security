package com.snhu.sslserver;

/** Standalone JDK-only smoke test; does NOT test the Spring web server or TLS. */
public final class ChecksumSmokeTest {
    public static void main(String[] args) {
        HashService service = new HashService();
        String data = "Artemis Financial | Nathan Burlison | CS305 Project Two | 2026-10-25 | 7f42c9";
        String digest = service.sha256Hex(data);
        if (digest.length() != 64 || !service.verifySha256(data, digest)
                || service.verifySha256(data + " (tampered)", digest)
                || !"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
                    .equals(service.sha256Hex("abc"))) {
            throw new AssertionError("Checksum test failed");
        }
        System.out.println("Developer: Nathan Burlison");
        System.out.println("Unique data: " + data);
        System.out.println("Algorithm: SHA-256");
        System.out.println("SHA-256 checksum: " + digest);
        System.out.println("Original verified: true");
        System.out.println("Tampered verified: false");
        System.out.println("Known-answer vector abc: PASS");
        System.out.println("Standalone JDK checksum checks: PASS");
        System.out.println("Spring HTTPS endpoint: NOT TESTED HERE");
    }
}
