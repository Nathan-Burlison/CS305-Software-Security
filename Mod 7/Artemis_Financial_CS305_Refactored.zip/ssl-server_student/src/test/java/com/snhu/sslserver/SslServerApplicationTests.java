package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// Supply an in-memory dummy keystore configuration only if server startup is tested.
// This smoke test checks that Spring application classes load without binding port 8443.
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE,
        properties = {
            "server.ssl.enabled=false",
            "ARTEMIS_KEYSTORE_PASSWORD=not-used-in-this-test"
        })
class SslServerApplicationTests {
    @Test
    void contextLoads() { }
}
