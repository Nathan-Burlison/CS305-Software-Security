package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HashServiceTest {
    private final HashService service = new HashService();

    @Test
    void sha256UsesUtf8AndReturns64HexCharacters() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
                service.sha256Hex("abc"));
        assertEquals(64, service.sha256Hex("Financial records \u20ac").length());
    }

    @Test
    void verificationPassesForOriginalDataAndFailsForChanges() {
        String value = "Artemis demo file content";
        String expected = service.sha256Hex(value);
        assertTrue(service.verifySha256(value, expected));
        assertTrue(service.verifySha256(value, expected.toUpperCase()));
        assertFalse(service.verifySha256(value + "!", expected));
        assertFalse(service.verifySha256(value, "xyz"));
        assertFalse(service.verifySha256(value, null));
    }

    @Test
    void nullDataIsRejected() {
        assertThrows(NullPointerException.class, () -> service.sha256Hex(null));
        assertThrows(NullPointerException.class, () -> service.verifySha256(null, "00"));
    }
}
