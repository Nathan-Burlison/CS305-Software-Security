package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;
import static org.junit.jupiter.api.Assertions.*;

class HashControllerTest {
    private final HashController controller = new HashController();

    @Test
    void sampleContainsNamedUniqueStringAndCorrectDigest() {
        HashController.HashResponse response = controller.sampleHash();
        assertEquals("Nathan Burlison", response.developer());
        assertEquals("SHA-256", response.algorithm());
        assertTrue(response.data().contains("7f42c9"));
        assertTrue(new HashService().verifySha256(response.data(), response.checksum()));
    }

    @Test
    void verificationDetectsAlteredData() {
        String value = "my financial record";
        String checksum = new HashService().sha256Hex(value);
        assertTrue(controller.verify(new HashController.VerificationRequest(value, checksum)).verified());
        assertFalse(controller.verify(new HashController.VerificationRequest(value + "X", checksum)).verified());
        assertThrows(ResponseStatusException.class,
                () -> controller.verify(new HashController.VerificationRequest(null, checksum)));
        assertThrows(ResponseStatusException.class,
                () -> controller.verify(new HashController.VerificationRequest("x".repeat(16_385), checksum)));
    }
}
