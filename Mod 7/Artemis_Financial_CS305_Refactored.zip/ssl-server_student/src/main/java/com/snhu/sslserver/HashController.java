package com.snhu.sslserver;

import org.springframework.http.MediaType;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

/** Minimal checksum demonstration. Not an authenticated file-upload API. */
@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
public class HashController {
    public static final String DEVELOPER = "Nathan Burlison";
    public static final String SAMPLE_DATA =
            "Artemis Financial | Nathan Burlison | CS305 Project Two | 2026-10-25 | 7f42c9";
    private static final int MAX_DATA_LENGTH = 16_384;
    private final HashService hashService = new HashService();

    @GetMapping("/hash")
    public HashResponse sampleHash() {
        String checksum = hashService.sha256Hex(SAMPLE_DATA);
        return new HashResponse(DEVELOPER, SAMPLE_DATA, "SHA-256", checksum);
    }

    @PostMapping(path = "/verify", consumes = MediaType.APPLICATION_JSON_VALUE)
    public VerificationResponse verify(@RequestBody VerificationRequest request) {
        if (request == null || request.data() == null || request.expectedChecksum() == null
                || request.data().length() > MAX_DATA_LENGTH) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "data and expectedChecksum are required; data is limited to 16,384 characters");
        }
        return new VerificationResponse("SHA-256",
                hashService.verifySha256(request.data(), request.expectedChecksum()));
    }

    public record HashResponse(String developer, String data, String algorithm, String checksum) { }
    public record VerificationRequest(String data, String expectedChecksum) { }
    public record VerificationResponse(String algorithm, boolean verified) { }
}
