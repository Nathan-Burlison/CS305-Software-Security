package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;

/** Calculates SHA-256 checksums and verifies a supplied, trusted checksum. */
public final class HashService {
    private static final char[] HEX = "0123456789abcdef".toCharArray();

    public String sha256Hex(String data) {
        Objects.requireNonNull(data, "data cannot be null");
        byte[] digest = sha256(data);
        char[] hex = new char[digest.length * 2];
        for (int i = 0; i < digest.length; i++) {
            int value = digest[i] & 0xff;
            hex[i * 2] = HEX[value >>> 4];
            hex[i * 2 + 1] = HEX[value & 0x0f];
        }
        return new String(hex);
    }

    /** A hash comparison detects alterations only when expectedHex is trusted. */
    public boolean verifySha256(String data, String expectedHex) {
        Objects.requireNonNull(data, "data cannot be null");
        if (expectedHex == null || expectedHex.length() != 64) {
            return false;
        }
        byte[] expected = new byte[32];
        for (int i = 0; i < expected.length; i++) {
            int hi = Character.digit(expectedHex.charAt(i * 2), 16);
            int lo = Character.digit(expectedHex.charAt(i * 2 + 1), 16);
            if (hi < 0 || lo < 0) {
                return false;
            }
            expected[i] = (byte) ((hi << 4) | lo);
        }
        return MessageDigest.isEqual(sha256(data), expected);
    }

    private byte[] sha256(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return digest.digest(data.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException error) {
            throw new IllegalStateException("SHA-256 is unavailable", error);
        }
    }
}
