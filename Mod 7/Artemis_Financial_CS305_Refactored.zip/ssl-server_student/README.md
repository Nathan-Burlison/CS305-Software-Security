# Artemis Financial - CS 305 Project Two

A refactoring of the supplied Spring Boot starter for a **local HTTPS demo** and a SHA-256 checksum-verification API. The supplied code had no checksum route and an incomplete SSL configuration. The original 2020-era Spring Boot and dependency-check versions have been updated.

## Important scope and security notes

- This is a **course demonstration**, not a production financial platform. The sample does not implement account authentication, authorization, persistence, financial record storage, audit logging, or a certificate signed by a trusted certificate authority.
- SHA-256 detects data alteration **only if the expected digest arrives from an independent, trusted source**. An adversary who can change both data and digest defeats this comparison. Use HMAC-SHA-256 or a digital signature where sender authenticity is required.
- The self-signed localhost certificate encrypts the TLS connection but is not browser-trusted until you explicitly trust it for local development. Do **not** disable certificate verification in production.
- Private keys, local passwords, and vulnerability-service API keys must remain outside the submitted ZIP / source control.
- The external Spring Boot build and OWASP Dependency-Check scan have **not** been completed in the provided offline build environment. Run and capture them locally before claiming a successful deployment.

## Requirements

JDK 21, Maven 3.9+ (or Maven Wrapper with network access), internet to download artifacts and CVE data, Eclipse/IDE optional. This project targets Spring Boot **4.1.2** and OWASP Dependency-Check Maven **13.0.0**.

## Create the HTTPS certificate (local only)

In PowerShell, within the unzipped project folder:

```powershell
$env:ARTEMIS_KEYSTORE_PASSWORD = Read-Host 'Local PKCS12 password'
.\scripts\setup-local-cert.ps1
keytool -printcert -file certs\artemis-localhost.cer
```

Or on Linux/macOS:

```bash
export ARTEMIS_KEYSTORE_PASSWORD='your-own-strong-local-password'
bash scripts/setup-local-cert.sh
keytool -printcert -file certs/artemis-localhost.cer
```

A demonstration **public certificate only** is provided at `evidence/artemis-demo-public.cer`. Regenerate your own matching CER and `.p12` using the script. **Never upload the generated `certs/artemis-localhost.p12` or its password.**

## Build, launch, and visit the secure endpoint

```powershell
.\mvnw.cmd clean test
.\mvnw.cmd spring-boot:run
```

On Linux/macOS, use `./mvnw` instead of `.\mvnw.cmd`. Visit `https://localhost:8443/hash`. For your course screenshot, trust your **locally generated certificate** using your browser/OS's local development process; otherwise browsers show a certificate-identity warning because the certificate is self-signed. You should see JSON containing your developer name, unique data string, algorithm, and 64-character checksum.

To verify a trusted digest with the same data, use a second terminal:

```bash
curl --cacert certs/artemis-localhost.cer https://localhost:8443/hash
curl --cacert certs/artemis-localhost.cer -H 'Content-Type: application/json' \
  -d '{"data":"abc","expectedChecksum":"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"}' \
  https://localhost:8443/verify
```

Note: some curl TLS installations require adding the local certificate to a trusted certificate store rather than passing it to `--cacert`.

## Run dependency check and capture report

```powershell
.\mvnw.cmd org.owasp:dependency-check-maven:check
```

The plugin needs internet access to update vulnerability intelligence and may be subject to NVD API limits; configure your NVD API key **privately** following the OWASP tool documentation if needed. Open `target/dependency-check-report.html` and check findings, especially any new runtime dependencies and transitive libraries. A clean report cannot be asserted before scanning. Take screenshots of the report and app execution and insert them into the matching report sections.

## Standalone tests without Maven

```bash
bash scripts/run-jdk-checksum-test.sh
```

This separately compiles and tests only `HashService.java` against JDK 21; it does **not** test Spring application startup, HTTPS binding, API routing, or dependency risks. The captured result is under `evidence/checksum-smoke-output.txt`.

## Primary code files

- `src/main/java/com/snhu/sslserver/SslServerApplication.java`: application entry point.
- `src/main/java/com/snhu/sslserver/HashService.java`: UTF-8 SHA-256 and digest comparison.
- `src/main/java/com/snhu/sslserver/HashController.java`: `GET /hash` demo; `POST /verify` verification.
- `src/main/resources/application.properties`: loopback-only HTTPS on 8443; PKCS12 password from environment.
- `src/test/java/com/snhu/sslserver/HashServiceTest.java` and `HashControllerTest.java`: unit tests to run with Maven.
- `scripts/setup-local-cert.ps1` / `.sh`: Keytool instructions automated.

## Checklist to finish the SNHU submission

1. Run Maven tests and correct any version-related compilation or runtime issues.
2. Launch the Spring application, capture the Eclipse console screenshot **without errors**.
3. Capture `https://localhost:8443/hash` in browser and confirm the local cert is trusted.
4. Run OWASP Dependency-Check, review its HTML findings, address introduced vulnerabilities, re-scan, and capture the actual scan results.
5. Replace the clearly marked pending screenshot blocks in the report. Current report does not represent these unperformed steps as passing.

References: NIST SP 800-52 Rev. 2 (TLS), NIST FIPS 180-4 (SHA-256), RFC 9846 (TLS 1.3), OWASP Dependency-Check, and Spring Boot 4.1.2 documentation.
