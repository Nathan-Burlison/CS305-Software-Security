Evidence provenance (October 2026)
================================
certificate-evidence.png:
  Actual screenshot of a graphical xterm showing a selected, unmodified subset of
  keytool -printcert output from the generated public certificate.
  Complete Keytool output is provided in certificate-details.txt.
checksum-evidence.png:
  Actual xterm screenshot containing JDK 21 standalone SHA-256 test output.
  Exact text is in checksum-smoke-output.txt.
artemis-demo-public.cer:
  Actual public DER certificate exported using Java Keytool; no private key included.

The Spring Boot HTTPS browser screenshot, Maven build results and the actual
OWASP dependency-check report are NOT included because internet/Maven access
was unavailable. See build-validation-blocker.txt. Screenshots of a local
Spring server or OWASP report must be obtained by the user after local execution.
