$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($env:ARTEMIS_KEYSTORE_PASSWORD)) {
    throw 'Set ARTEMIS_KEYSTORE_PASSWORD to a strong, private local password.'
}
New-Item -Path 'certs' -ItemType Directory -Force | Out-Null
& keytool -genkeypair -alias artemis-localhost -keyalg RSA -keysize 3072 `
    -sigalg SHA256withRSA -validity 365 -storetype PKCS12 `
    -keystore certs/artemis-localhost.p12 `
    -storepass $env:ARTEMIS_KEYSTORE_PASSWORD -keypass $env:ARTEMIS_KEYSTORE_PASSWORD `
    -dname 'CN=localhost,OU=CS 305,O=Artemis Financial,L=Local,ST=Local,C=US' `
    -ext 'SAN=dns:localhost,ip:127.0.0.1' -noprompt
if ($LASTEXITCODE -ne 0) { throw 'Certificate generation failed' }
& keytool -exportcert -alias artemis-localhost `
    -keystore certs/artemis-localhost.p12 `
    -storepass $env:ARTEMIS_KEYSTORE_PASSWORD -file certs/artemis-localhost.cer
if ($LASTEXITCODE -ne 0) { throw 'Certificate export failed' }
Write-Host 'Local-only PKCS12 and CER created. Do not commit certs/*.p12.'
