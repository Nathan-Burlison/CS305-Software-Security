#!/usr/bin/env bash
set -euo pipefail
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
javac -d "$TMP_DIR" \
  src/main/java/com/snhu/sslserver/HashService.java \
  src/test/java/com/snhu/sslserver/ChecksumSmokeTest.java
java -cp "$TMP_DIR" com.snhu.sslserver.ChecksumSmokeTest
