#!/usr/bin/env bash
set -euo pipefail
if [[ -z "${ARTEMIS_KEYSTORE_PASSWORD:-}" ]]; then
  echo 'Set ARTEMIS_KEYSTORE_PASSWORD to a strong, private local password.' >&2
  exit 1
fi
mkdir -p certs
keytool -genkeypair -alias artemis-localhost -keyalg RSA -keysize 3072 \
  -sigalg SHA256withRSA -validity 365 -storetype PKCS12 \
  -keystore certs/artemis-localhost.p12 \
  -storepass "$ARTEMIS_KEYSTORE_PASSWORD" -keypass "$ARTEMIS_KEYSTORE_PASSWORD" \
  -dname 'CN=localhost,OU=CS 305,O=Artemis Financial,L=Local,ST=Local,C=US' \
  -ext 'SAN=dns:localhost,ip:127.0.0.1' -noprompt
keytool -exportcert -alias artemis-localhost \
  -keystore certs/artemis-localhost.p12 \
  -storepass "$ARTEMIS_KEYSTORE_PASSWORD" \
  -file certs/artemis-localhost.cer
printf 'Created local-only PKCS12 keystore and public CER. Do not commit certs/*.p12.\n'
