`dependency-check-before.html` is an actual user-generated report.
`dependency-check-after.html` does not exist until you rerun OWASP with the updated pom.xml.
Do not submit only the before report: rubric requires both reports from real scanner executions.
