# Run from PowerShell in the rest-service project directory:
#   .\RUN_CHECKS.ps1 -Phase Before
# Review the baseline HTML, then add VERIFIED false-positive entries to suppression.xml.
#   .\RUN_CHECKS.ps1 -Phase After
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Before','After')]
    [string]$Phase
)

$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    if (-not (Get-Command mvn -ErrorAction SilentlyContinue)) {
        throw 'Maven (mvn) not found on PATH. Use Eclipse Run As > Maven build... with goals described in SCAN_INSTRUCTIONS.md, or install Maven.'
    }
    if ($Phase -eq 'Before') {
        $pom = 'pom.baseline.xml'
        $reportName = 'dependency-check-before.html'
    } else {
        $pom = 'pom.xml'
        $reportName = 'dependency-check-after.html'
        if (-not ((Get-Content 'suppression.xml' -Raw) -match '<suppress\b')) {
            Write-Warning 'There are no suppression rules. This is correct ONLY if the baseline has no confirmed false positives.'
        }
    }

    & mvn -f $pom org.owasp:dependency-check-maven:12.2.2:check
    if ($LASTEXITCODE -ne 0) { throw "Dependency-Check failed (exit code $LASTEXITCODE); no valid report can be claimed." }

    $source = Join-Path $PSScriptRoot 'target/dependency-check-report.html'
    if (-not (Test-Path $source)) { throw "Expected OWASP HTML report not generated: $source" }

    $outDir = Join-Path $PSScriptRoot 'reports'
    New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    $dest = Join-Path $outDir $reportName
    Copy-Item -Path $source -Destination $dest -Force
    Write-Host "Saved actual OWASP report: $dest"
}
finally { Pop-Location }
